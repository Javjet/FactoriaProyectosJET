package com.iessanalberto.jet;

public class Alumno extends Usuario{
    private String centro;

    public Alumno(String rol, String nombre, String contraseña, String familiaProfesional, String email, String[] gustos) {
        super(rol, nombre, contraseña, familiaProfesional, email, gustos);
    }
}
